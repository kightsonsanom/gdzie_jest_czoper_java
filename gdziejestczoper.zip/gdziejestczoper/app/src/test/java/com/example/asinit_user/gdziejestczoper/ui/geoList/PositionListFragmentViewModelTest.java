package com.example.asinit_user.gdziejestczoper.ui.geoList;

import android.arch.lifecycle.LiveData;

import com.example.asinit_user.gdziejestczoper.db.Repository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import static org.mockito.Mockito.mock;

@RunWith(JUnit4.class)
public class PositionListFragmentViewModelTest {

    private Repository  repository =  mock(Repository.class);
    private PositionListFragmentViewModel viewModel;

    @Before
    public void setUp(){
        viewModel = new PositionListFragmentViewModel(repository);
    }


}