package com.example.asinit_user.gdziejestczoper.viewobjects;


public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}
