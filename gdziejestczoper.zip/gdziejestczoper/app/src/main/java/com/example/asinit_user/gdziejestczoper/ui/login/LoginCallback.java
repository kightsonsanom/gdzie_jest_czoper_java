package com.example.asinit_user.gdziejestczoper.ui.login;


public interface LoginCallback {

    void showSuccess();
    void showError();
}
