package com.example.asinit_user.gdziejestczoper.ui.login;


public interface LoginManagerCallback {

    void onLoginSuccess();
    void onLoginFailure();
}
