# GdzieJestCzoper #

Android application which main purpose is to monitor users positions during the day. It synchronizes the data with remote server in order for all the users to get up-to-date locations of their collegues. 

### Application architecture###

The app uses the MVVM architecture pattern.